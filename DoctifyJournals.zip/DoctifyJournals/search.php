<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Search articles</title>
<?php include("config.php"); ?>
</head>

<body>
<h1><u><center>Searched Article</center></h1></u>

<?php $z=$_REQUEST['search'];  //get data from search bar

								//<!--select data from table article where article name is equal to the name entered in the search bar-->
$sql = "SELECT ArticleName,link, image 		
		FROM  article  
		WHERE ArticleName='$z' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
	   echo '<div class="responsive">
	   			<div class="img">
					<a href='.$row['link'].' image src="data:image/jpeg;base64,'.base64_encode( $row['image']).'"/>
      					<img alt="Trolltunga Norway" image src="'.$row['image'].'"/ width="300" height="200">';// add link to image, encode image, fetch image,
		 echo '<div class="desc">';																				//and display it on the page
		 echo $row["ArticleName"];					//get the article name from database.
		 echo '</div>
  </div>
</div>';
   
   }
} else {
    echo "0 results";
}
$conn->close();
?>

</body>
</html>
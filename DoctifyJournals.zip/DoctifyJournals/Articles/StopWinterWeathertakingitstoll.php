We all know that the winter weather can take its toll on your skin. Chapped lips, breakouts, dry skin, or a dull pallid complexion will affect many of us. But what isn’t widely considered is the effect that winter can have on your skin’s general health and the aging process.

Winter weather attacks your skin on several fronts.  For a start, in winter you’re generally less healthy anyway: the flu season is here and colds and viruses abound. You can often spot when somebody is feeling under the weather just by the condition of their skin. Then there’s Christmas, the season of parties and excess for many people. It is also dark at this time of year, so we get less exposure to daylight. Not only can this affect your mood, but your skin will stop producing vitamin D at this time of year. Your skin’s final winter enemy is the modern central heating system, which might keep you warm but will also directly affect your skin.

Luckily there are a number of really simple things you can do to ensure you keep your skin in tiptop condition. If you’d like bright, glowing and healthy skin during these dark winter months, look no further than the following tips.

Don’t wash with hot water

Did you know that using excessively hot water when washing actually strips away the natural oils that protect your skin? This process also disrupts your skin’s pH balance. So, to avoid your face becoming dry, always wash with tepid or cool water. The skin on your face is generally more sensitive than the rest of your body so taking extra care of your face by using lukewarm, tepid or cool water, and try not to wash your face in the bath or shower.

Hot water

Exfoliate

Damp cold air outside and dry warm air inside modern buildings can create a build-up of dead skin cells on your skin’s surface. This can give your skin a patchy, flaky or dry appearance. Regular exfoliating with a good quality scrub should therefore be a priority at this time of year. Exfoliating removes dead skin cells, cleanses your skin and stimulates your skin’s blood circulation. Eliminating the build-up of dead skin cells will also help improve the skin’s absorption of moisturisers, topical treatments and other skin care products. Be careful not to over-exfoliate though. This can cause your skin to become inflamed, irritated and even encourage acne breakouts.

Cleanse & Tone

A good quality cleanser or toner is another must at this time of year. Cleansers & toners clean away excessive dirt and oil from the skin’s pores.  Try not to use soaps for cleansing as they can strip away your skin’s essential oils. To ensure your skin’s natural pH is not disturbed it’s also important that you use non-alcoholic products. You should also consider whether your skin is dry or oily when choosing your cleansers or toners. It may also be necessary to change your products in the wintertime as your skin adjusts to the colder weather. If you want to find out what type of skin you have and the most suitable topical products for your skin it’s a good idea to have your skin professionally analysed at a specialist skin clinic. Good quality clinics often have specialist equipment that can objectively measure your skin’s features and provide you with bespoke treatment plans as well as advice on the best cleansers and toners.

Diet

One of the most important factors that affects your skin’s health and appearance is your diet. In the winter the quality of our diet tends to suffer. Christmas, New Year and the relapse after you’ve broken your New Year’s resolutions just make it difficult to remain focused on this.  To be fair it’s probably important for our mental health that we do party at this time of year as long as we manage to keep it in perspective.

Healthy eating don’t have to be dull and there are some great healthy recipes out there. My healthy recipes booklet is due to be launched very soon. The booklet is full of healthy recipes specifically designed to keep your skin in tiptop condition using ingredients that feed your skin as well as your taste buds.

Intermittent fasting is another good tactic to help maintain optimum health. It’s also a great way to help you lose weight after the Christmas period. Fasting triggers a process called autophagy. This is a complex intercellular process that is thought to disassemble and recycle unnecessary cellular junk, effectively detoxifying your body. There are lots of different fasting methods you can choose from which are surprisingly easy to do once you get used to them. Maintaining good hydration is always important no matter what the season. Winter is no exception, so drink up.

Vitamin D

Another huge factor that affects your health in the winter months is the lack of natural sunlight. Between the months of September and March you body isn’t able to produce any Vitamin D due to the strength of winter sunlight. This is why it is sometimes called the sunshine vitamin. It’s actually very hard to consume enough vitamin D through your diet alone and it is only sufficient exposure to ultraviolet B light that will enable your body to produce it. This isn’t possible in the UK during the winter months, so the only alternatives are to either take vitamin D supplements or treat yourself to a tropical holiday. Your skin directly reflects your internal health which is affected by your vitamin D levels. So, to ensure your skin keeps its natural glow, a good way to maintain your internal health is to take Vitamin D supplements – even if you do manage to fit in a winter holiday.

Moisturisers

Dry central heating, cold winds and hot baths all contribute to dry skin in winter. A good quality moisturiser is then probably one of the most essential skin care products in your wash bag. But how do you choose the right one for you with literally hundreds of moisturiser available?

Peptides are good ingredient to look for. They work by binding moisture within your skin and are thought to help your skin self-repair. Recent studies have reported that auto-inducing peptides are involved in cell-to-cell communication and it is this that helps your skin repair itself.

Hypoallergenic formulas are designed to lock your skin’s moisture in for a prolonged period and so are also good to look out for. Shea butter is another popular ingredient in many moisturisers and for good reason. Shea butter is known to contain high levels of vitamin A, which has anti-inflammatory qualities. If you’re looking for a good moisturiser you won’t go far wrong with the Obagi range of products.

sunscreen

Sunscreen

It seems counterintuitive that during these dark winter months the use of an affective sunscreen should be a key part of your skin regime. To understand why it’s necessary to appreciate the difference between UVA and UVB light.

UVB light is responsible for your skin’s production of Vitamin D. However because the sun doesn’t rise high enough in the sky during the winter months for UVB light to penetrate the Earth’s atmosphere your skin stops produce Vitamin D. UVA on the other hand doesn’t require the sun to be high in sky to penetrate the earth’s atmosphere and so is present throughout the winter months.  It is this UVA that causes the damage to your skin.

UVA is known to play a major part in the aging of your skin by penetrating the deeper layers of the dermis, accelerating wrinkling and stimulating melasma (dark patches). Although it has been recognised for some time that UVB causes sunburn and cancers until recently UVA wasn’t thought to be a noteworthy contributor. Recent studies however have shown that UVA may also initiate and exacerbate the development of skin cancers. Unfortunately UVA light passes straight through glass, making sun protection necessary even when you’re indoors. So always ensure you wear some form of SPF protection.

So there you have it; your top tips for ensuring you keep your skin in fabulous condition over the winter months. And remember, the summer will be here very soon… with different skin issues to consider!
Summer 2016 spells the beginning of the Rio Olympics and the whole world is getting ready to spend just over two weeks absolutely sports mad.  With that in mind, here at Doctify we have produced a guide on how you can use this summer’s Olympic inspiration to get more involved in sport.

Running

Did you know that running has the highest rate of calorie burn out of all the events taking place at this years’ Olympics? It is estimated that on average people burn 465 calories in half an hour. To put this into perspective this is the equivalent of burning off two slices of sponge cake. The main benefit of running is that it’s free and you can do it anywhere. It has also been found to reduce the risk of heart disease, strokes and diabetes.

If you have never been a runner it is important to ease yourself in to running slowly. Do not go straight into running a 5k. This will help you to enjoy the experience and most importantly avoid injury. You should also do a gentle walking warm up for at least 5 minutes to avoid pulling any muscles.

Swimming

With over 30 different events at this years’ Rio Olympics, swimming is second only to athletics in popularity. It is also one of the biggest calorie burners and it is estimated that an average person can burn 400 calories doing a slow swim for an hour. Just like in running, a beginner swimmer should build up slowly. You could start with a couple of swims a week lasting between 10 and 30 minutes. Then as you improve add another 5 minutes each week. It is also important to not feel like you need to swim continuously at the beginning. You could start by swimming a lap, taking a break then swimming another. Again, this could be gradually built up so you swim more laps in between each break.

You are also more likely to exercise more muscles if you switch up your stoke, but if you are not a confident swimmer then stick to a stroke that you are good at and you’ll be able to swim for longer and burn more calories.

Cycling

Cycling is an easy way to travel and enjoy the outdoors this summer, as well as a great way of working out. In fact you can burn over 500 calories per hour. Like before start slowly and build your way up increasing the distance and incline, as you get more confident. No matter where you are cycling it is important to be traffic savvy and always wear a helmet. In the US head injuries from not wearing a helmet account for 75% of cycling fatalities. If used correctly they are 90% effective in preventing serious brain injuries.

Tennis

Tennis is one of the most popular sports of the summer with the warmer weather bringing great tennis events. To celebrate Andy Murray becoming team GB’s flag bearer at this summers Olympics, at Doctify we have been looking into the best ways to get involved in tennis. Not only can you burn over 400 calories an hour, but tennis is also a great way to get involved in sport with a friend. You can visit the British tennis website to find your closest tennis court . They also have information on local classes where you can try out fun activities such as Cardio tennis. This is a group activity aimed at people of all abilities and features a number of drills, using tennis balls to work out to music.
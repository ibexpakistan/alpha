This month’s news features an exclusive story on a seven year old piece of research. There’s also some exciting news about hot meals and bad news for office workers.

Another death at the office

Your desk job is killing you, screamed newspaper headlines last month. People who sit for more than eight hours a day at work and are also inactive the rest of the time are more likely to die, says research in The Lancet. In fact, they are 59% more likely to die than active people who spend less than four hours sitting a day. Interestingly, those doing an hour or more of moderately intense activity a day but also sit eight hours a day at work were not at higher risk of death.

Double dip reporting

Have you ever recoiled in disgust at the sight of someone double dipping? They pick up a nacho, dip, bite, then dip again. As well as being dreadfully uncouth, it is scientifically proven to be unhygienic. A study found that bacteria levels in dips increase after double dipping and that bacteria levels in salsa after double dipping are higher than in cheese or chocolate dips. Important research, but strange that this blog about a 2009 research study would get so much news coverage.

Pea values

Do you feel guilty if you feed your child ready meals? New research in the Archives of Diseases in Childhood might make you feel better as it suggests children’s ready meals might be more healthy than home cooked food. The study compared 278 savoury children’s ready meals to 408 home cooked children’s recipes. Ready meals had more types of vegetable and contained less protein and fat. Half of the home cooked meals contained more calories than recommendations suggest. But don’t throw your recipe books out just yet: ready meals cost twice as much, and a third of them didn’t meet recommended energy requirements. You also have to wonder if the things they looked on this research really tell you if the food is healthy. For instance, a portion of broccoli is surely better for you than one pea and a slice of carrot. But this study only looked at number of different vegetables, not portions. Perhaps none of this matters though, as no matter how many vegetables you serve your child, they’ll probably leave them all on the plate.
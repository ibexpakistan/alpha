Acne is one of the most common skin conditions – I see people with acne in my clinic everyday.  In fact, nearly 85% of people aged between 12 and 24 will suffer from acne at some point. It’s not just a problem for teenagers though: older adults get it too, particularly women.

Acne itself doesn’t kill of course, but it can cause scarring and the effects on self-image and confidence often lead to depression and anxiety disorders. Incredibly, nearly 20% of acne sufferers have thought about or considered suicide because of their skin disease, according to a recent survey commissioned by the British Skin Foundation.

Whilst there are a large number of validated, effective treatments for treating acne available from either a GP or dermatologist, many people with acne are also keen to take control of their lives and make lifestyle changes that may help.  One of the questions I’m asked the most is what effect diet has on acne.

Historically, the relationship between diet and acne has been highly controversial.  Before the 1960s, dietary advice was a standard part of acne therapy.  Patients at this time were discouraged from eating foods such as chocolate, sweets and fizzy drinks.  However, following two pivotal scientific studies in the late 1960s and early 1970s, the link between diet and acne fell out of favour and was largely abandoned.  Researchers, however, have since re-examined these studies and found various methodological flaws.

Although the total number of studies carried out over the past 40 years is relatively small, there appears to be a growing body of support that certain types of food may aggravate acne.  Emerging data suggests that high glycaemic index diets may have a role to play in how acne develops.  There is also limited evidence that some dairy (in particular skimmed milk) may also have some influence.

High Glycaemic Load Diets

Foods that have a high glycaemic index (eg. sugar, sweets, pizza, soft drinks, fast food, white bread) are rapidly absorbed by the body leading to high blood sugar or glucose levels.  Raised circulating blood glucose levels promote the release of the hormone insulin and IGF-1 (insulin growth factor 1).  Both of these increase oil or sebum production and act on the body to produce more male hormones known as androgens (both men and women have androgens).  All these factors together are thought to promote the development of acne.

Dairy

The link between dairy as a cause or aggravating factor for acne is much weaker.   There are a number of proposed hypotheses surrounding how dairy products may worsen skin disease.  It is possible that dairy acts by a similar mechanism to diets rich in carbohydrates by promoting insulin and IGF1 production.  There are also other suggestions that milk from dairy cows either naturally contains growth hormones or is treated with growth hormones.  These can in turn increase androgen levels, which drive oil glands to release more sebum.

The Western diet has often been researched as a potential cause for acne.  Traditionally, Canadian Inuits and Zulu populations did not have acne.  However, acne prevalence increased among the first group after adopting a diet of processed foods, beef and dairy.  Among the Zulu population, acne development was attributed to migration from rural areas into cities.  Similarly, native populations in Papua New Guinea and Paraguay that follow a “paleo-like” diet did not have acne.

The ideal “anti-acne” diet would be low in sugar and refined carbohydrates.  Vegetables and fruit with low glycaemic index and fish high in omega 3 fatty acids should be encouraged.  If there is concern that acne is being driven by diet, then a careful food diary should be kept for at least 12 weeks.

The current strength of recommendation based on existing science for the role of diet in acne (specifically high glycaemic index and dairy) remains of limited quality.  There is no doubt that we will see a growth of research in this field since gaps in research and knowledge remain.  Dermatologists will benefit from listening to their patients.  Whilst acne should not be treated with diet alone, it may provide an adjunctive measure to tried and tested validated treatments that already exist for this troublesome disease.
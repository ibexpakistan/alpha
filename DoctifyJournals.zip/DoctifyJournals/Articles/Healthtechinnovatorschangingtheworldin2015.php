Here at the Doctify Journal it’s our new year’s resolution to bring you the most interesting and relevant health news and features directly from the experts. You might have already seen our 2015 healthcare round-up and experts’ 2016 predictions, or our editor’s first monthly health news review. As Doctify gets in gear for 2016 after its first Christmas we thought we’d look around at who the other new or trending healthcare innovators are.

Skin Analytics

Skin analytics

Have you ever been told to “get that mole checked”? For £29 you can now do just that using the Skin analytics iphone app. Dermatologists use a special lens called a dermatoscope to view moles in more detail than you can see with the naked eye or a camera lens. Skin analytics turns your iphone into a dermatoscope with a special lens that they send you in the post. The image gets sent across to a dermatologist who either gives you the all clear or tells you to go and see a specialist. In December they crowdfunded over their £450,000 target, so expect to hear more from them in 2016.

http://bleepbleeps.com/

Bleep bleeps

There’s a big market of thirty something professionals going through the planning to have, struggling to have, and then finally thank goodness we’ve managed to have a baby phase of their lives. They want children almost as much as they used to want the latest iphone. Now there’s a new set of gadgets for them: bleep bleeps, the most self-confident health start-up of the year. bleep bleeps are “cute, connected devices that help you get pregnant, give birth, look after your baby and raise your child.” Their products range from the sublime David Camera baby monitor to the…well, a semen analyser called master bates.

https://www.headspace.com/how-it-works

Headspace

If you were fortunate enough not to get a mindfulness colouring book for Christmas you might still be interested in mindfulness as a way to de-stress and improve your mood. Headspace is a slick celebrity endorsed “gym membership for the mind” with a free 10 minute daily meditation and more extensive subscription service.

http://oviva.com/uk/
Oviva

Google any symptom and you’ll soon find some dietary advice about how to resolve it. Cut carbs, go gluten free, switch to paleo, take a supplement. How about getting some expert advice from a dietician instead? Oviva will be your dietician in your pocket from £75 a month. This include access to your own named dietician and personalised feedback on your progress 3-5 times a week (depending on your subscription).

https://www.elbi.com/
Elbi

“Noble deeds and hot baths are the best cures for depression” said the author Dodie Smith. Charitable acts app Ebli makes doing a good deed as easy as running a bath. The app wants to help you contribute to a charitable project in those minutes you currently spend scrolling through Twitter on the train, bus or toilet. Examples of “good on the go”, as they put it, include creating digital doodles to decorate dorms in orphanages, naming newborn puppies, and drawing funny faces to cheer up sick kids.

www.doctify.co.uk

Doctify

Seeing a specialist privately is still an oddly old fashioned experience. You mostly sort it out over the phone, often without really knowing much about the doctor you’re going to see. The whole process was crying out to be Uber-fied, and finally has been by Doctify. Go online, see who’s available, which insurers cover them, check their reviews and book your appointment.
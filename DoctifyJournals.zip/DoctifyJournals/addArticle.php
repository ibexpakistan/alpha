<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Add article</title>
<style>
.error {color: #FF0000;}
</style>
<?php include("config.php"); ?>
</head>

<body>

<?php 

if(!((!isset($_POST['cat']) || empty($_POST['cat'])) 		//The isset () function is used to check whether a variable is set or not.
&& (!isset($_POST['wName']) || empty($_POST['wName']))		//The isset() function return false if testing variable contains a NULL value.
&& (!isset($_POST['aName']) || empty($_POST['aName']))		//The empty() function is used to check whether a variable is empty or contains some value.
&& (!isset($_POST['article']) || empty($_POST['article']))
&& (!isset($_FILES['image']))))
	{
		if(getimagesize($_FILES['image']['tmp_name']) == FALSE)	//check if image is selected or not??? if not, the upload an image.
																//***The getimagesize() function will determine the size of any given image file and return 
                {												//the dimensions along with the file type and a height/width text string to be used inside
                    echo "Please select an image.";				// a normal HTML IMG tag and the correspondent HTTP content type.
                }
                else{
					$image= addslashes($_FILES['image']['tmp_name']); // Quote string with slashes
					$image= file_get_contents($image);					//Reads entire file into a string
					//$image= base64_encode($image);
		$iName=$_POST['aName'];			//assign article name to image.
		str_replace(' ', '_', $iName);	//replace white spaces from string i.e. image/article name.
		$newimage = fopen("./Articles/images/".$iName.".jpg", "w") or die("Unable to open file!");	//open folder /Article/images/ open a new file here in write mode.
		fwrite($newimage, $image); //save that image 
		fclose($newimage); // close file.
					
		
		
		$aName=$_POST['aName'];
		$string=$aName;
		$string = preg_replace('/\s+/', '', $string);	//replace white space from string name.
		$newFile = fopen("./Articles/".$string.".php", "w") or die("Unable to open file!");	//open a new file in the folder /Article in write mode.
		fwrite($newFile, $_POST['article']);	//post article data in this file.
		fclose($newFile);						//close that file.
		
$sql = "INSERT INTO `article` (category_id, writerName, ArticleName, date, image, link)		
		VALUES ( '".$_POST['cat']."', '".$_POST['wName']."', '".$_POST['aName']."', Now(), './Articles/images/".$iName.".jpg', './Articles/".$string.".php')";
//echo $sql;			//insert data into database;
$result = $conn->query($sql);

	
	}
	}
?>


<form action="addArticle.php" method="POST" enctype="multipart/form-data"><!--create a form-->
				<!--create a drop down list-->
category:	
<select name="cat" required>
  <option value="1">Ask the expert</option>
  <option value="2">Consulting room</option>
  <option value="3">Healthy livings</option>
  <option value="4">News and opinion</option>
  <option value="5">On the pulse</option>
</select><br>
writerName: <input type="text" name="wName" required><br><!--create a text field-->
ArticleName: <input type="text" name="aName" required><br><!--create a text field-->
image: <input type="file" name="image" required /> <br><!--create a text field-->
Article Text:<br><br>
 <textarea rows="30" cols="80" name="article" required></textarea><br><!--create a text area-->
<input type="submit" value="submit">
</form>

</body>
</html>
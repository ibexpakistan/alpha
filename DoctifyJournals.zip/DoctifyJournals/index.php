<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Doctify</title><br>

</head>

<body>
<h1><a href="articles.php">Articles</a></h1><h1><a href="categories.php">Categories</a></h1>

<span> search bar</span>
<form action="search.php" method="post">
<input type="text" name="search" placeholder="Search...."><br>
<input type="submit" value="Search">
</form>

<h1><a href="addArticle.php">Add articles</a></h1>
</body>
</html>
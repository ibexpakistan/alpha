<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
.error {color: #FF0000;}
</style>
<?php include("config.php"); ?>

</head>

<body>

<?php 

$wNameErr = $aNameErr = "";
$wName = $aName =  "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
    $wName = test_input($_POST["wName"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$wName)) {
      $wNameErr = "Only letters and white space allowed"; 
    }
  
    $aName = test_input($_POST["aName"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$aName)) {
      $aNameErr = "Only letters and white space allowed"; 
    }
  }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if(!((!isset($_POST['cat']) || empty($_POST['cat']))
&& (!isset($_POST['wName']) || empty($_POST['wName']))
&& (!isset($_POST['aName']) || empty($_POST['aName']))
&& (!isset($_POST['article']) || empty($_POST['article']))
&& (!isset($_FILES['image']))))
	{
		if(getimagesize($_FILES['image']['tmp_name']) == FALSE)
                {
                    echo "Please select an image.";
                }
                else{
					$image= addslashes($_FILES['image']['tmp_name']);
					$image= file_get_contents($image);
					//$image= base64_encode($image);
		$iName=$_POST['aName'];
		str_replace(' ', '_', $iName);
		$newimage = fopen("./Articles/images/".$iName.".jpg", "w") or die("Unable to open file!");
		fwrite($newimage, $image);
		fclose($newimage);
					
		
		
		$aName=$_POST['aName'];
		$string=$aName;
		$string = preg_replace('/\s+/', '', $string);
		$newFile = fopen("./Articles/".$string.".php", "w") or die("Unable to open file!");
		fwrite($newFile, $_POST['article']);
		fclose($newFile);
		$string=$aName;
		$string = preg_replace('/\s+/', '', $string);
$sql = "INSERT INTO `article` (category_id, writerName, ArticleName, date, image, link)
		VALUES ( '".$_POST['cat']."', '".$_POST['wName']."', '".$_POST['aName']."', Now(), './Articles/images/".$iName.".jpg', './Articles/".$string.".php')";
//echo $sql;
$result = $conn->query($sql);

	
	}
	}
?>


<form action="<?php htmlspecialchars($_SERVER["addArticle.php"]);?>" method="POST" enctype="multipart/form-data">

category:
<select name="cat" required>
  <option value=""></option>
  <option value="1">Ask the expert</option>
  <option value="2">Consulting room</option>
  <option value="3">Healthy livings</option>
  <option value="4">News and opinion</option>
  <option value="5">On the pulse</option>
</select><br>
writerName: <input type="text" name="wName" required><br>
ArticleName: <input type="text" name="aName" required><br>
image: <input type="file" name="image" required /> <br>
Article Text:<br><br>
 <textarea rows="30" cols="80" name="article" required></textarea><br>
<input type="submit" value="submit">
</form>

</body>
</html><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
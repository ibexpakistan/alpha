<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>categories</title>
<?php include("config.php") ?>
<link href="style.css" rel="stylesheet" type="text/css">

</head>
<body>

<h1><u><center>CATEGORIES</center></u></h1>

<?php

$sql = "SELECT * FROM category";      //select data from category table;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
	    echo '<div class="responsive">
	   			<div class="img">
					<a href='.$row['cLink'].' image src="data:image/jpeg;base64,'.base64_encode( $row['c_image']).'"/>
      					<img alt="Trolltunga Norway" image src="data:image/jpeg;base64,'.base64_encode( $row['c_image']).'"/ width="300" height="200" >';// add link to image, encode image, fetch image,
						                                                                                                  //and display it on the page
		 echo '<div class="desc">';
		 echo $row["categoryName"];     //get the category name from database.
		 echo '</div>
  </div>
</div>';

   }
}
?>
</body>
</html>
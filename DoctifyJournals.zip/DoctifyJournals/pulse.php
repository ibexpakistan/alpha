<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>On the pulse</title>
<?php include("config.php") ?>
</head>

<body>
<h1><u><center>ARTICLE LIST</center></u></h1>

<?php


$sql = "SELECT a.ArticleName, a.image, a.link
		FROM category c , article a 
		WHERE c.category_id = 5 AND a.category_id = c.category_id ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
	   echo '<div class="responsive">
	   			<div class="img">
					<a href='.$row['link'].' image src="data:image/jpeg;base64,'.base64_encode( $row['image']).'"/>
      					<img alt="Trolltunga Norway" image src="'.$row['image'].'"/ width="300" height="200">';
		 echo '<div class="desc">';
		 echo $row["ArticleName"];
		 echo '</div>
  </div>
</div>';
   
   }
} else {
    echo "0 results";
}
$conn->close();
?>

</body>
</html>


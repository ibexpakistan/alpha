<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "articles";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// Check connection

?>
<body>
</body>
</html>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "articles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "SELECT a.ArticleName, a.Article, c.categoryName, c.category_id
		FROM category c , article a 
		WHERE c.category_id = 3 AND a.category_id = c.category_id ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
        echo "Category id: " . $row["category_id"]. "<br><br> Category Name: " . $row["categoryName"]. "<br>";
		echo "<br>Article name " . $row["ArticleName"]."<br><br>Article : " . $row["Article"]. "<br>";
   }
} else {
    echo "0 results";
}
$conn->close();
?>


</body>
</html>
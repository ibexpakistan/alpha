<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>articles</title>
<?php include("config.php") ?>
</head>
<?php

$sql = "SELECT * FROM article";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
        echo "article_id: " . $row["article_id"]. "<br><br>Category: " . $row["category"]. "<br><br>Writer Name " . $row["writerName"]. "<br><br>";
		echo "Article Name: " . $row["ArticleName"]. " <br><br>Date & Time " . $row["date"]. "<br><br>Article: " . $row["Article"]. "<br>";
   }
} else {
    echo "0 results";
}
$conn->close();
?>
<body>
</body>
</html>
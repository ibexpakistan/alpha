<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<?php include("config.php"); ?>
</head>

<body>
<?php $z=$_REQUEST['Moles and skin cancer'];


$sql = "SELECT a.ArticleName, a.Article
		FROM  article a 
		WHERE a.ArticleName='$z' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
        
		echo "<br>Article name " . $row["ArticleName"]."<br><br>Article : " . $row["Article"]. "<br>";
   }
} else {
    echo "0 results";
}
$conn->close();
?>
</body>
</html>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Doctify journals</title>
</head>

<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "articles";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "CREATE TABLE article (
Article LONGTEXT,
ArticleName LONGTEXT NOT NULL,
SpecialistName LONGTEXT NOT NULL,
month TEXT NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>

</body>
</html>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Doctify journals</title>
</head>

<body>
<?php
include("config.php");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "SELECT Article, ArticleName, SpecialistName, month FROM articles";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Article: " . $row["Article"]. "<br><br>"." - ArticleName: " . $row["ArticleName"]. "<br><br>"."- SpecialistName " . 
		$row["SpecialistName"] . "<br><br>"." - month" . $row["month"] . "<br><br>";
    }
} else {
    echo "0 results";
}





$conn->close();
?>

</body>
</html>
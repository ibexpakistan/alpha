<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<?php

$stmt = $conn->prepare("INSERT INTO article (Article, ArticleName, SpecialistName, month) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $Article, $ArticleName, $SpecialistName, $month);

$Article="Every man is born with one. And if we chaps lived until we are 120 years old it will cause every single one of us problems. The prostate gland is what I’m talking about – an important little thing that plays a big part in our lives. It pays to know about the symptoms it can cause, and also how we go about checking it.";
$ArticleName="Every man is born with one";
$SpecialistName="Dr Martin Saweirs";
$month="24 Jul 2016 4:05 PM";
$stmt->execute();

$Article="We all know it’s important to drink water to stay hydrated and healthy. However drinking water during meal times may be a great way of controlling food intake and feeling fuller quicker. We had a look at some interesting studies that show how water can really fill you up.";
$ArticleName="Can drinking water before meals make you eat less?";
$SpecialistName="Doctify Team";
$month="18 Jul 2016 12:17 PM";
$stmt->execute();

$Article="With the summer holidays here, my aim is to find plenty of time to do nothing. But even when I get the chance to, I usually end up doing something. I see the same in healthcare all the time, where there’s so often an overwhelming urge to do something";
$ArticleName="July Health News";
$SpecialistName="Tom Nolan";
$month="12 Jul 2016 10:30 AM";
$stmt->execute();

echo "New records created successfully";

$stmt->close();
?>
<body>
</body>
</html>
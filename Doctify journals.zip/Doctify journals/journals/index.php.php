<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Doctify journals</title>
</head>

<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "articles"

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbName);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

?>

</body>
</html>
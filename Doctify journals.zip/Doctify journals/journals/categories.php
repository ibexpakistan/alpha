<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>categories</title>
<?php include("config.php") ?>
</head>
<?php
include("config.php");
?>
<body>



<?php

$sql = "SELECT * FROM category";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
        echo "Category id: " . $row["category_id"]. "<br><br>category name " . $row["categoryName"];
		echo '<image src="data:image/jpeg;base64,'.base64_encode( $row['c_image']).'"/>';


   }

}




?>












<span> search bar</span>
<form action="search.php" method="post">
<input type="text" name="search" placeholder="Search...."><br>
<input type="submit" value="Search">
</form>

<span>Articles And categories</span>
<form action="article.php" method="post">



<input type="image" src="img.jpg" name="Moles and skin cancer" value="submit"></input><br>
</form>


<span>Articles</span>
<a href="fetch.php"><h3 >Articles</h3><br></a>


<span>Category 1</span>
<a href="ask.php">Ask the Expert</h3></a><br>

<span>Category 2</span>
<a href="Consult.php"><h3>Consulting Room</h3></a><br>

<span>Category 3</span>
<a href="health.php"><h3 >healthy living</h3><br></a>

<span>Category 4</span>
<a href="news.php"><h3>news and opinnion</h3><br></a>

<span>Category 5</span>
<a href="pulse.php"><h3 >on the pulse</h3><br></a>
<script type="text/javascript">

<?php
function article(){
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "articles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "SELECT a.ArticleName, a.Article, c.categoryName, c.category_id
		FROM category c , article a 
		WHERE c.category_id = 1 AND a.category_id = c.category_id ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
   while($row = $result->fetch_assoc()) {
        echo "Category id: " . $row["category_id"]. "<br><br> Category Name: " . $row["categoryName"]. "<br>";
		echo "<br>Article name " . $row["ArticleName"]."<br><br>Article : " . $row["Article"]. "<br>";
   }
} else {
    echo "0 results";
}
$conn->close();
}
?>

</body>
</html>